# Murdhi's Server — Android app

A small Android app that opens your home server app (port 8095) full screen.

- Default address: http://192.168.118.119:8095
- If it can't connect, it asks for a new address (use your Tailscale `100.x.x.x:8095` when away from home).
- Every push builds a new APK automatically (Actions tab), and it's attached to a Release.
