package com.murdhi.server;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    private static final String DEFAULT_URL = "http://192.168.118.119:8095";
    private WebView web;
    private SharedPreferences prefs;
    private boolean dialogOpen = false;

    private String serverUrl() {
        return prefs.getString("url", DEFAULT_URL);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("murdhi", MODE_PRIVATE);

        getWindow().setStatusBarColor(Color.rgb(11, 13, 26));
        getWindow().setNavigationBarColor(Color.rgb(11, 13, 26));

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11, 13, 26));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                Uri home = Uri.parse(serverUrl());
                boolean sameHost = target.getHost() != null && target.getHost().equals(home.getHost());
                boolean samePort = target.getPort() == home.getPort();
                if (sameHost && samePort) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, target));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    askForUrl("Can't reach your server.\n\nAt home use: " + DEFAULT_URL
                            + "\nAway from home use your Tailscale address, like http://100.x.x.x:8095");
                }
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(serverUrl());
        }
    }

    private void askForUrl(String message) {
        if (dialogOpen || isFinishing()) {
            return;
        }
        dialogOpen = true;

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(serverUrl());
        LinearLayout box = new LinearLayout(this);
        box.setPadding(50, 20, 50, 0);
        box.addView(input, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        new AlertDialog.Builder(this)
                .setTitle("Murdhi's Server")
                .setMessage(message)
                .setView(box)
                .setCancelable(false)
                .setPositiveButton("Connect", (d, w) -> {
                    dialogOpen = false;
                    String url = input.getText().toString().trim();
                    if (!url.startsWith("http")) {
                        url = "http://" + url;
                    }
                    prefs.edit().putString("url", url).apply();
                    web.loadUrl(url);
                })
                .setNeutralButton("Reset", (d, w) -> {
                    dialogOpen = false;
                    prefs.edit().remove("url").apply();
                    web.loadUrl(DEFAULT_URL);
                })
                .setNegativeButton("Retry", (d, w) -> {
                    dialogOpen = false;
                    web.reload();
                })
                .show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }
}
